import React, { Component } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Drawer from '@material-ui/core/Drawer';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import { checkAuthentication } from './helpers';
import { withAuth } from '@okta/okta-react';
import { withStyles } from "@material-ui/core/styles";

const drawerWidth = 240;

const useStyles = theme => ({
  root: {
    display: 'flex',
  },
  title:{
    flexGrow: 1,
  },
  appBar: {
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  main:{
    padding: theme.spacing(8)
  },
  drawerHeader: {
      display: 'flex',
      alignItems: 'center',
      padding: theme.spacing(0, 1),
      ...theme.mixins.toolbar,
      justifyContent: 'flex-end',
    },
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    width: 200,
  },
  menu: {
    width: 200,
  },
});


export default withAuth(withStyles(useStyles)(class Home extends Component {

  constructor(props) {
    super(props);
    this.state = { authenticated: null, userinfo: null };
    this.checkAuthentication = checkAuthentication.bind(this);
    this.login = this.login.bind(this);
    this.logout = this.logout.bind(this);

  }

  async componentDidMount() {
     this.checkAuthentication();

  }

  async componentDidUpdate() {
    this.checkAuthentication();
  }

  async login()
  {
     this.props.auth.login('/');
  }





  async logout()
  {
     this.props.auth.logout('/');

  }

get  showMenuOptions(){
    if(this.state.authenticated)
    {
       return  <div> Welcome {this.state.userinfo.name}<Button color="inherit" onClick={this.logout}>Logout</Button></div>
    }
    else {
      return <Button color="inherit" className={this.props.classes.menuButton} onClick={this.login}>Login</Button>
    }
  }




render () {
  return (
    <div className={this.props.classes.root}>

      <AppBar position="fixed"
        className={this.props.classes.appBar }>
        <Toolbar>
          <IconButton edge="start"  className={this.props.classes.menuButton} color="inherit" aria-label="menu">
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" className={this.props.classes.title}>
            Events
          </Typography>
          {this.showMenuOptions}
        </Toolbar>

      </AppBar>

      <main className={this.props.classes.main}  >

             something
           </main>



    </div>
  );
}
}));
