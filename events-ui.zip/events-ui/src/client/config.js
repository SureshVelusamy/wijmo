const CLIENT_ID = process.env.CLIENT_ID || '0oa15gvkiaA49cgz2357';
const ISSUER = process.env.ISSUER || 'https://dev-915434.okta.com/oauth2/default';

export default {
  oidc: {
    clientId: CLIENT_ID,
    issuer: ISSUER,
    redirectUri: 'http://localhost:8080/implicit/callback',
    scope: 'openid profile email',
  },
  resourceServer: {
    messagesUrl: 'http://localhost:8000/api/messages',
  },
};
